

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

import javax.management.RuntimeErrorException;


class BestFirst {
	static class State {
		private Ilayout layout;
		private State father;
		private double g;
		public State(Ilayout l, State n) {
			layout = l;
			father = n;
			if (father!=null)
				g = father.g + l.getG();
			else g = 0.0;
		}
		public String toString() { return layout.toString(); }
		public double getG() {return g;}
        @Override
        public boolean equals(Object o){
            if(o instanceof State){
                State state = (State)o;
                return layout.isGoal(state.layout); 
            }
            throw new RuntimeErrorException(null, "Object is not of type State");
        }
	}
	private State actual;
	private Ilayout objective;
	
	final private List<State> sucessores(final State n) {
		List<State> sucs = new ArrayList<>();
		List<Ilayout> children = n.layout.children();
		for(Ilayout e: children) {
			if (n.father == null || !e.equals(n.father.layout)){
				State nn = new State(e, n);
				sucs.add(nn);
			}
		}
		return sucs;
	}
	
	final public Iterator<State> solve(Ilayout s, Ilayout goal) {
		objective =s;
		Queue<State> abertos = new PriorityQueue<>(10,(s1, s2) -> (int) Math.signum(s1.getG()-s2.getG()));
		List<State> fechados = new ArrayList<>();
		abertos.add(new State(s, null));
		List<State> sucs; 
		LinkedList<State> f=new LinkedList<>();
		while(!objective.isGoal(goal))  {
			if(abertos.isEmpty()) {
				System.exit(0);
			}
			actual=abertos.peek();
			abertos.remove(actual);
			if(actual.layout.isGoal(goal)) {
				objective=actual.layout;
				while(actual!=null) {
					f.addFirst(actual);
					actual=actual.father;
				}
			}
			else {
				sucs=sucessores(actual);
				fechados.add(actual);
				for(State s1:sucs) {
					if(!fechados.contains(s1)) {
						abertos.add(s1);
					}
				}
			}
		}
		return f.iterator();
	}
}
