

import java.util.ArrayList;
import java.util.List;

class Board implements Ilayout, Cloneable {
	private static final int dim=2;
	private int board[][];
	private double g;
	public Board(){ board = new int[dim][dim];}
	
	public Board(String str) throws IllegalStateException {
		if (str.length() != dim*dim) throw new IllegalStateException("Invalid arg in Board constructor");
		board = new int[dim][dim];
		int si=0;
		for(int i=0; i<dim; i++)
			for(int j=0; j<dim; j++)
				board[i][j] = Character.getNumericValue(str.charAt(si++));
	}
	
	public String toString() {
		String res="";
		for(int i=0;i<dim;i++) {
			for(int j=0;j<dim;j++) {
				if(board[i][j]==0) res+=" ";
				else res+=board[i][j];
			}
			res+="\n";
		}
		return res;
	}
	
	@Override
	public Board clone() {
		Board o=new Board();
		for(int i=0;i<dim;i++) {
			for(int j=0;j<dim;j++) {
				o.board[i][j]=board[i][j];
			}
		}
		return o;
	}
	
	public double impar_par(int a,int b) {
		if(a%2==0 && b%2==0) return 20;
		else if(a%2!=0 && b%2!=0)return 1;
		else return 5;
	}
	public List<Ilayout> children() {
		List<Ilayout> t1=new ArrayList<>();
			
		Board cloned=clone();
		cloned.board[0][0]=board[0][1];//left
		cloned.board[0][1]=board[0][0];
		cloned.g=impar_par(board[0][1],board[0][0]);
		t1.add(cloned);

		Board cloned1= clone();
		cloned1.board[1][0]=board[1][1];//right
		cloned1.board[1][1]=board[1][0];
		cloned1.g=impar_par(board[1][0],board[1][1]);
		t1.add(cloned1);

		Board cloned2=clone();
		cloned2.board[0][1]=board[1][1];//down
		cloned2.board[1][1]=board[0][1];
		cloned2.g=impar_par(board[1][1],board[0][1]);
		t1.add(cloned2);
				
		Board cloned3= clone();
		cloned3.board[0][0]=board[1][0];//up
		cloned3.board[1][0]=board[0][0];
		cloned3.g=impar_par(board[1][0],board[0][0]);
		t1.add(cloned3);
		
		Board cloned4= clone();
		cloned4.board[1][0]=board[0][1];
		cloned4.board[0][1]=board[1][0];
		cloned4.g=impar_par(board[1][0],board[0][1]);
		t1.add(cloned4);
		
		Board cloned5= clone();
		cloned5.board[0][0]=board[1][1];
		cloned5.board[1][1]=board[0][0];
		cloned5.g=impar_par(board[1][1],board[0][0]);
		t1.add(cloned5);
		return t1;
	}
	
	
	public boolean isGoal(Ilayout l) {
		Board o=(Board) l;
		for(int i=0;i<dim;i++) {
			for(int j=0;j<dim;j++) {
				if(board[i][j]!=o.board[i][j]) {
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public double getG() {
		return g;
	}
}
